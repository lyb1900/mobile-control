import xlrd
import matplotlib.pyplot as plt
import numpy as np
import tkinter as tk

def main():
    # 1.打开execl文件

    data = xlrd.open_workbook(r"G:\家庭财务报表23年版.xls")
    # 2.获得名为工商的sheet
    table = data.sheet_by_name("工商")
    # 3.获得行数
    nrows = table.nrows
    # 4.获得列数
    ncols = table.ncols
    # 5.获取第一行数据
    row1 = table.row_values(0)
    # 6.获取第一列数据
    col1 = table.col_values(0)
    # 7.获取第二行第二列的数据
    cell = table.cell(1, 1).value
    # 8.遍历所有的行
    for i in range(nrows):
        print(table.row_values(i))
    # 9.遍历所有的列
    for i in range(ncols):
        print(table.col_values(i))
    # 10.遍历所有的单元格
    for i in range(nrows):
        for j in range(ncols):
            print(table.cell(i, j).value)
    # 根据B列和E列画图

def draw():

    # 1.获取数据
    data = xlrd.open_workbook(r"G:\家庭财务报表23年版.xls")
    table = data.sheet_by_name("工商")
    nrows = table.nrows
    ncols = table.ncols
    # 2.获取B列和E列数据
    B = table.col_values(1)
    E = table.col_values(4)
    # 3.去掉第一行数据
    B = B[1:]
    # B单元格数据类型为年月日


    E = E[1:]
    # 4.绘制图形
    # 4.1设置中文显示
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    # 4.2绘图
    plt.bar(B, E, label="工商")
    plt.xlabel("年份")
    plt.ylabel("金额")
    plt.title("工商图")
    plt.legend()
    plt.show()

def hiwatch():
    #一个主界面大小是 300*400 
    top = tk.Tk()
    #显示一个秒表
    label = tk.Label(top, text="00:00:00", font=("黑体", 30), bg="white")
    label.pack()
    #上面有一个按钮，点击开始计时，再次点击停止计时
    button = tk.Button(top, text="开始计时", font=("黑体", 30), bg="white")
    button.pack()
    top.mainloop()
    
import tkinter as tk
from datetime import datetime

class Stopwatch:
    def __init__(self):
        self.running = False
        self.elapsed_time = 0

    def start(self):
        self.start_time = datetime.now()
        self.running = True

    def stop(self):
        self.end_time = datetime.now()
        self.running = False
        self.elapsed_time += (self.end_time - self.start_time).total_seconds()

    def reset(self):
        self.elapsed_time = 0
        self.running = False

class App:
    def __init__(self, master):
        self.master = master
        self.stopwatch = Stopwatch()
        self.display = tk.Label(master, font=('Arial', 30), text='00:00:00.0')
        self.display.pack()
        self.start_button = tk.Button(master, text='Start', command=self.start)
        self.start_button.pack(side=tk.LEFT, padx=10)
        self.stop_button = tk.Button(master, text='Stop', command=self.stop)
        self.stop_button.pack(side=tk.LEFT, padx=10)
        self.reset_button = tk.Button(master, text='Reset', command=self.reset)
        self.reset_button.pack(side=tk.LEFT, padx=10)
        self.quit_button = tk.Button(master, text='Quit', command=self.quit)
        self.quit_button.pack(side=tk.LEFT, padx=10)

    def start(self):
        self.stopwatch.start()
        self.update_display()

    def stop(self):
        self.stopwatch.stop()

    def reset(self):
        self.stopwatch.reset()
        self.display.config(text='00:00:00.0')

    def quit(self):
        self.master.destroy()

    def update_display(self):
        if self.stopwatch.running:
            self.display.config(text=self.format_time())
            self.master.after(100, self.update_display)

    def format_time(self):
        elapsed_time = int(self.stopwatch.elapsed_time * 10)
        minutes, seconds = divmod(elapsed_time, 60)
        hours, minutes = divmod(minutes, 60)
        return f'{hours:02d}:{minutes:02d}:{seconds:02d}.{elapsed_time % 10}'



# main()
if __name__ == '__main__':
    hiwatch()
    root = tk.Tk()
    app = App(root)
    root.mainloop()
